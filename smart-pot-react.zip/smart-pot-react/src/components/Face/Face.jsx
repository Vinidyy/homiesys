import { motion } from 'framer-motion'

export default function Face({ emotion }) {
  const eyeSize = 56

  const tint =
    emotion === 'hot' ? 'bg-hot/30' :
    emotion === 'cold' ? 'bg-cold/30' :
    emotion === 'dizzy' ? 'bg-accent/20' :
    emotion === 'scared' ? 'bg-warn/25' : 'bg-accent/10'

  const mouthVariant = {
    happy: { scaleY: 1, borderRadius: 9999, rotate: 0, height: 10, width: 120 },
    hot:   { scaleY: 1, borderRadius: 9999, rotate: 180, height: 10, width: 120 },
    cold:  { scaleY: 1, borderRadius: 9999, rotate: 180, height: 10, width: 120 },
    dizzy: { scaleY: 1.1, borderRadius: 9999, rotate: 0, height: 20, width: 20 },
    scared:{ scaleY: 1.2, borderRadius: 9999, rotate: 0, height: 32, width: 32 },
  }[emotion] || { scaleY: 1, borderRadius: 9999, rotate: 0, height: 10, width: 120 }

  const blinkTransition = { duration: 0.15, repeat: Infinity, repeatDelay: 3.6 }
  const eyeWander = {
    rotate: emotion === 'dizzy' ? [0, 12, -12, 8, 0] : 0,
    transition: { duration: emotion === 'dizzy' ? 0.9 : 3, repeat: Infinity, ease: 'easeInOut' }
  }

  const scaredJitter = emotion === 'scared' ? 'animate-jitter' : ''

  return (
    <div className={`relative flex flex-col items-center justify-center p-4 ${scaredJitter}`}>
      <div className={`absolute inset-6 rounded-full ${tint} face-glow`} />

      <div className="relative flex items-center justify-center gap-16">
        {[0,1].map((i) => (
          <motion.div
            key={i}
            className="relative"
            style={{ width: eyeSize, height: eyeSize }}
            animate={eyeWander}
          >
            <motion.div
              className="absolute inset-0 bg-white rounded-full shadow-lg"
              style={{ transformOrigin: '50% 50%' }}
              animate={{ scaleY: [1, 0.05, 1] }}
              transition={blinkTransition}
            />
            <motion.div
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-black rounded-full"
              style={{ width: eyeSize*0.38, height: eyeSize*0.38 }}
              animate={{ y: emotion === 'happy' ? [0, -1, 0, 1, 0] : 0 }}
              transition={{ duration: 6, repeat: Infinity }}
            />
          </motion.div>
        ))}
      </div>

      <motion.div
        className="mt-6 bg-white mx-auto"
        animate={mouthVariant}
        transition={{ type: 'spring', stiffness: 240, damping: 18 }}
        style={{ borderRadius: mouthVariant.borderRadius }}
      />

      {emotion === 'hot' && (
        <div className="absolute right-20 top-8 flex flex-col gap-1">
          <div className="w-2 h-4 rounded-full bg-hot/90 animate-float" />
          <div className="w-2 h-6 rounded-full bg-hot/80 animate-float" style={{ animationDelay: '0.2s' }} />
          <div className="w-2 h-3 rounded-full bg-hot/70 animate-float" style={{ animationDelay: '0.4s' }} />
        </div>
      )}
      {emotion === 'cold' && (
        <div className="absolute left-16 top-10 flex gap-2">
          <div className="w-3 h-3 rounded-full bg-cold/70 animate-float" />
          <div className="w-2 h-2 rounded-full bg-cold/60 animate-float" style={{ animationDelay: '0.15s' }} />
          <div className="w-2 h-2 rounded-full bg-cold/60 animate-float" style={{ animationDelay: '0.3s' }} />
        </div>
      )}
      {emotion === 'dizzy' && (
        <motion.div
          className="absolute -top-2"
          animate={{ rotate: 360 }}
          transition={{ duration: 2.5, repeat: Infinity, ease: 'linear' }}
        >
          <div className="w-24 h-24 border-2 border-accent/60 rounded-full" />
        </motion.div>
      )}
    </div>
  )
}
